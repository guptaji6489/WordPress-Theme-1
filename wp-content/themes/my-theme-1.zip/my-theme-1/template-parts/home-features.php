<?php
/*
* This is ourhome featured.
*/
?>

<h1>Home page featured Area</h1>