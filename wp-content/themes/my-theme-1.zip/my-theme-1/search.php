<?php
/*
* This is used to display search.
*/
?>
