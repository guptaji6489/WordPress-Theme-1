<?php
/*
* This is to display single archive.
*/
?>
