<?php
/*
* This is to display sidebar.
*/
?>
<div class="main-sidebar-inner">
    <?php
    dynamic_sidebar('sidebar-1');
    ?>
</div>
